package com.mejorandola.ejemplo;

import android.support.v4.app.Fragment;

public class FragmentName extends
		Fragment {

}
